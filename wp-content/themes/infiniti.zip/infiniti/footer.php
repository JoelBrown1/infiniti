<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package infiniti
 */
?>

	</div>

	<footer id="colophon" class="site-footer" role="contentinfo">
		©2014 All rights reserved. Infiniti.ca is a trademark of infiniti global. OasisHD.ca is a trademark of Blue Ant Media
	</footer>
</div>

<?php wp_footer(); ?>

</body>
</html>
